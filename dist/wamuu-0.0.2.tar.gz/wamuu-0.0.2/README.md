<h1 align="center">🌪️ Wamuu Project 🌪️</h1>

<div align="center">
	<a href="link_for_webite">
	<img height = "250em" src = "https://github.com/FernandoSchett/wind_turb_cable/assets/80331486/498e0f85-d5ca-4a74-9a6e-c2eb7ab14d39" />
    </a>
</div>

## Developed by 💻:

- [Fernando Schettini](https://linktr.ee/fernandoschett).
- [Pedro Miranda]().

## Special thanks to 🥰:
- [Felipe Islame](http://lattes.cnpq.br/0058216016593116), your experience and knowledge have been invaluable to our progress.

## About 🤔:

## Resourses 🧑‍🔬:

- 
- 

## Dependencies 🚚:

The project dependencies are described in  ```./dependencies/requirements.txt``` within the repository. In summary, heres what you're gonna need in order to run the project:

- [```dependencie <version>```](http:link.com).
- 

For installing dependencies more quickly, you can run the following command at terminal, inside the clonned repository:

	sudo apt update && sudo apt install python3 python3-pip
    pip3 install -r ./dependencies/requirements.txt

Make sure you have all Dependencies before running the project.

## How to install 🔬:

To install Wamuu Project and use it on your own code, use:

	pip install wamuu

## Results 📈:

### Tools Used 🛠️: 

- [VScode](https://code.visualstudio.com/). 

## How to contribute 🫂:

Feel free to create a new branch, fork the project, create a new Issue or make a pull request contact one of us to develop at Wamuu Project.

## Licence 📜:

[Apache V2](https://choosealicense.com/licenses/apache-2.0/)

## References 📙:
	
[1] <last_author_name>, <first_author_name>. <work_title>. XX/XX/XX.
	
[2] <work_title>, <author_name>. Avaliable in: <https://www.link.com>. Access in em XX/XX/XX.

### Important links 🔗:

